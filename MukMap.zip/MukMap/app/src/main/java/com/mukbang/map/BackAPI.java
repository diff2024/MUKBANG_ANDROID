package com.mukbang.map;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface BackAPI {
    @GET("/Read/MarkerList") // @전송방식(데이터를 전송할 서버 파일명)
    Call<List<MarkerData>> Read_List(@Query("channel_id") String channel_id); // Call<응답받을 데이터형> 함수명(서버에 전달할 데이터)

}

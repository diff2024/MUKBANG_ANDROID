package com.mukbang.map;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.UiSettings;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.util.FusedLocationSource;
import com.naver.maps.map.util.MarkerIcons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, ActivityCompat.OnRequestPermissionsResultCallback, View.OnClickListener {
    private NaverMap mNaverMap;
    private FusedLocationSource locationSource;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private static final String[] PERMISSIONS = {
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
    };
    private Marker[] markers;
    private int Marker_Count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_c1 = findViewById(R.id.btn_c1);
        Button btn_c2 = findViewById(R.id.btn_c2);
        Button btn_c3 = findViewById(R.id.btn_c3);

        btn_c1.setOnClickListener(this);
        btn_c2.setOnClickListener(this);
        btn_c3.setOnClickListener(this);

        btn_c1.setSelected(true);
        btn_c2.setSelected(true);
        btn_c3.setSelected(true);

        FragmentManager fragmentManager = getSupportFragmentManager();
        MapFragment mapFragment = (MapFragment) fragmentManager.findFragmentById(R.id.map);
        if(mapFragment == null){
            mapFragment = MapFragment.newInstance();
            fragmentManager.beginTransaction().add(R.id.map, mapFragment).commit();
        }

        //getMapAsync 호출해 비동기로 onMapReady 콜백 메서드 호출
        //onMapReady에서 NaverMap 객체를 받음.
        mapFragment.getMapAsync(this);

        //위치를 반환하는 구현체인 FusedLocationSource 생성
        locationSource = new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onClick(View v){
        if (v.getId() == R.id.btn_c1) {
            v.setSelected(!v.isSelected());

            Button btn_c1 = findViewById(R.id.btn_c1);
            if(v.isSelected()) {
                btn_c1.setTextColor(Color.parseColor("#FFFFFF"));
            }else{
                btn_c1.setTextColor(Color.parseColor("#000000"));
            }
            getMarker(mNaverMap, "N");
        } else if (v.getId() == R.id.btn_c2) {
            v.setSelected(!v.isSelected());

            Button btn_c2 = findViewById(R.id.btn_c2);
            if(v.isSelected()) {
                btn_c2.setTextColor(Color.parseColor("#FFFFFF"));
            }else{
                btn_c2.setTextColor(Color.parseColor("#000000"));
            }
            getMarker(mNaverMap, "N");
        } else if (v.getId() == R.id.btn_c3) {
            v.setSelected(!v.isSelected());

            Button btn_c3 = findViewById(R.id.btn_c3);
            if(v.isSelected()) {
                btn_c3.setTextColor(Color.parseColor("#FFFFFF"));
            }else{
                btn_c3.setTextColor(Color.parseColor("#000000"));
            }
            getMarker(mNaverMap, "N");
        }
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
        // NaverMap 객체 받아서 NaverMap 객체에 위치 소스 지정
        mNaverMap = naverMap;
        mNaverMap.setLocationSource(locationSource);

        UiSettings uiSettings = naverMap.getUiSettings();
        uiSettings.setCompassEnabled(false);
        uiSettings.setScaleBarEnabled(false);
        uiSettings.setZoomControlEnabled(false);
        uiSettings.setLocationButtonEnabled(true); // 현재위치

        CameraPosition cameraPosition = new CameraPosition(new LatLng(37.5666102, 126.9783881), 10);
        naverMap.setCameraPosition(cameraPosition);

        getMarker(naverMap, "Y");
        //Toast.makeText(getApplicationContext(), "1", Toast.LENGTH_SHORT).show();
        // 권한 확인, 결과는 onRequestPermissionResult 콜백 메서드 호출
        ActivityCompat.requestPermissions(this, PERMISSIONS, LOCATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // request code와 권한 획득 여부 확인
        if(requestCode == LOCATION_PERMISSION_REQUEST_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                mNaverMap.setLocationTrackingMode(LocationTrackingMode.Follow);
            }else{
                Toast.makeText(getApplicationContext(), "위치 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void getMarker(@NonNull NaverMap naverMap, @NonNull String init_YN) {
        String channel_id = "";
        if(init_YN.equals("N")) {
            if ((findViewById(R.id.btn_c1)).isSelected()) {
                channel_id = "C1";
            }

            if ((findViewById(R.id.btn_c2)).isSelected()) {
                if(channel_id.equals("")){
                    channel_id = "C2";
                }else{
                    channel_id = channel_id + ",C2";
                }
            }

            if ((findViewById(R.id.btn_c3)).isSelected()) {
                if(channel_id.equals("")){
                    channel_id = "C3";
                }else{
                    channel_id = channel_id + ",C3";
                }
            }

            if(channel_id.equals("")){
                for(int x=0; x<Marker_Count; x++){
                    markers[x].setMap(null);
                }
            }
        }else if(init_YN.equals("Y")){
            channel_id = "C1,C2,C3";
        }
        System.out.println("channel_id   " + channel_id);
        Retrofit retrofit = RetrofitClient.getInstance();
        BackAPI backAPI = retrofit.create(BackAPI.class);
        backAPI.Read_List(channel_id).enqueue(new Callback<List<MarkerData>>() {
            @Override
            public void onResponse(@NonNull Call<List<MarkerData>> call, @NonNull Response<List<MarkerData>> response) {
                if (response.isSuccessful()) {
                    System.out.println("> init_YN : " + init_YN);
                    // 서버로부터 전달받은 데이터
                    List<MarkerData> list = response.body();
                    if(init_YN.equals("Y")){
                        Marker_Count = list.size();
                    }

                    if(markers == null) {
                        markers = new Marker[list.size()];
                    }else{
                        for(int x=0; x<Marker_Count; x++){
                            markers[x].setMap(null);
                        }
                    }

                    int marker_cnt = 0;
                    for (MarkerData markerData : list) {
                        System.out.println("> getChannelId : " + markerData.getChannelId());
                        System.out.println("> getChannelName : " + markerData.getChannelName());
                        System.out.println("> getChannelMarkerColor : " + markerData.getChannelMarkerColor());
                        System.out.println("> getRestaurantId : " + markerData.getRestaurantId());
                        System.out.println("> getRestaurantName : " + markerData.getRestaurantName());
                        System.out.println("> getRestaurantAddress : " + markerData.getRestaurantAddress());
                        System.out.println("> getRestaurantLatitude : " + markerData.getRestaurantLatitude());
                        System.out.println("> getRestaurantLongitude : " + markerData.getRestaurantLongitude());

                        markers[marker_cnt] = new Marker();
                        markers[marker_cnt].setCaptionText(markerData.getRestaurantName());
                        markers[marker_cnt].setIcon(MarkerIcons.BLACK);
                        markers[marker_cnt].setIconTintColor(Color.parseColor("#" + markerData.getChannelMarkerColor()));
                        markers[marker_cnt].setPosition(new LatLng(Double.parseDouble(markerData.getRestaurantLatitude()), Double.parseDouble(markerData.getRestaurantLongitude())));
                        markers[marker_cnt].setMap(naverMap);
                        markers[marker_cnt].setOnClickListener(new Overlay.OnClickListener() {
                            @Override
                            public boolean onClick(@NonNull Overlay overlay) {
                                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                                ClipData clip = ClipData.newPlainText("label", markerData.getRestaurantAddress());
                                clipboard.setPrimaryClip(clip);
                                Toast.makeText(getApplication(), markerData.getRestaurantName() + " 주소가 복사 되었습니다.", Toast.LENGTH_SHORT).show();

                                return false;
                            }
                        });
                        marker_cnt++;
                    }
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<MarkerData>> call, @NonNull Throwable t) {
                System.out.println("channel_id   ??");
                t.printStackTrace();
            }
        });
    }
}